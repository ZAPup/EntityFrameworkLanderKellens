﻿using DataLayer;
using LeagueConsole.Managers;
using LeagueConsole.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.IO;

namespace LeagueConsole
{
    class Program
    {
        public static string Data = @"C:\Users\mkell\Desktop\foot.csv";
        public static League league;
        static void Main(string[] args)
        {
            league = new League();
            LeesData(Data);

            Boolean Afspeel = true;
            while (Afspeel)
            {
                Console.WriteLine("----- [MENU] -----");
                Console.WriteLine("[1] UPLOAD DATA");
                Console.WriteLine("[2] EDIT DATA");
                Console.WriteLine("[3] SLUIT APPLICATIE");
                Console.Write("Selectie?: ");
                String selection = Console.ReadLine();

                switch (selection)
                {
                    case "1":
                        using (var dataContext = new DataContext())
                        using (var context = dataContext.Database.BeginTransaction())
                        {
                            dataContext.Database.ExecuteSqlCommand("SET IDENTITY_INSERT [dbo].[Teams] ON");
                            VoegTeamToe(dataContext);
                            dataContext.Database.ExecuteSqlCommand("SET IDENTITY_INSERT [dbo].[Teams] OFF");

                            dataContext.Database.ExecuteSqlCommand("SET IDENTITY_INSERT [dbo].[Players] ON");
                            VoegSpelerToe(dataContext);
                            dataContext.Database.ExecuteSqlCommand("SET IDENTITY_INSERT [dbo].[Players] OFF");

                            dataContext.Database.ExecuteSqlCommand("SET IDENTITY_INSERT [dbo].[Transfers] ON");
                            VoegTransfersToe(dataContext);
                            dataContext.Database.ExecuteSqlCommand("SET IDENTITY_INSERT [dbo].[Transfers] OFF");
                            context.Commit();
                        }
                        break;
                    case "2":
                        EditManager.AanpasMenu();
                        break;
                    case "3":
                        Afspeel = false;
                        break;
                    default:
                        Console.Write("Verkeerde input, druk op ENTER om verder te gaan...");
                        Console.ReadLine();
                        break;
                }
            }
        }

        private static void LeesData(String path)
        {
            string[] readText = File.ReadAllLines(path);
            for (int i = 1; i < readText.Length; i++)
                aanmaakObject(readText[i]);
        }

        private static void aanmaakObject(String Line)
        {
            Random r = new Random();
            String[] temp = Line.Split(",");

            if (league.KrijgTeams().Find(x => x.ID.Equals(Int16.Parse(temp[4]))) == null)
                league.VoegTeamToe(new Team(Int16.Parse(temp[4]), temp[2], temp[6], temp[5]));
            Team x = league.KrijgTeams().Find(x => x.ID.Equals(Int16.Parse(temp[4])));
            Speler p = new Speler(league.KrijgAlleSpelers().Count + 1, Int32.Parse(temp[1]), temp[0], r.Next(0, 100), x, Int32.Parse(temp[3].Replace(" ", "")));
            league.VoegSpelerToe(p);
        }

        public static void VoegSpelerToe(DataContext context)
        {
            foreach (Speler item in league.KrijgAlleSpelers())
            {
                context.Spelers.Add(item);
            }
            context.SaveChanges();
        }
        public static void VoegTeamToe(DataContext context)
        {
            foreach (var item in league.KrijgTeams())
            {
                context.Teams.Add(item);
            }
            context.SaveChanges();
        }
        public static void VoegTransfersToe(DataContext context)
        {
            foreach (var item in league.KrijgAlleTransfers())
            {
                context.Transfers.Add(item);
            }
            context.SaveChanges();
        }
    }
}