﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace LeagueConsole.Migrations
{
    public partial class UpdateInit : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
