﻿using LeagueConsole.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LeagueConsole.Managers
{
    public class TransferManager
    {
        public static void BeheerTransfer()
        {
            Boolean afspelen = true;
            while (afspelen)
            {
                Console.WriteLine("----- [TRANSFERS] -----");
                Console.WriteLine("[1] MAAK TRANSFER");
                Console.WriteLine("[2] PRINT TRANSFERS");
                Console.WriteLine("[3] GA TERUG");
                Console.Write("Selectie?: ");
                String selectie = Console.ReadLine();

                switch (selectie)
                {
                    case "1":
                        MaakTransfer();
                        break;
                    case "2":
                        PrintTransfers();
                        break;
                    case "3":
                        afspelen = false;
                        break;
                    default:
                        Console.Write("Verkeerde input ingegeven, druk op ENTER om verder te gaan...");
                        Console.ReadLine();
                        break;
                }
            }
        }

        private static void MaakTransfer()
        {
            Speler speler;
            Team oudeTeam = null;
            Team nieuwTeam;
            int prijs;

            while (true)
            {
                Console.WriteLine("----- [MAAK TRANSFER] -----");
                Console.Write("Speler ID?: ");
                String spelerIDstring = Console.ReadLine();
                if (Int32.TryParse(spelerIDstring, out int spelerID))
                    using (DataContext data = new DataContext())
                    {
                        if (data.Teams.Where(x => x.ID == spelerID).Any())
                        {
                            speler = data.Spelers.Where(x => x.ID == spelerID).First();
                            break;
                        }
                        else
                        {
                            Console.Write("Geen speler terug gevonden met dit ID, druk op ENTER om verder te gaan...");
                            Console.ReadLine();
                        }
                    }
                else
                {
                    Console.Write("Geef een juist spelers ID in, druk op ENTER om verder te gaan...");
                    Console.ReadLine();
                }
            }

            if (speler.TeamID != 0)
            {
                using (DataContext data = new DataContext())
                {
                    if (data.Teams.Where(x => x.ID == speler.TeamID).Any())
                    {
                        oudeTeam = data.Teams.Where(x => x.ID == speler.TeamID).First();
                    }
                }
            }

            while (true)
            {
                Console.WriteLine("----- [MAAK TRANSFER] -----");
                Console.Write("Nieuw Team ID?: ");
                String teamIDString = Console.ReadLine();
                if (Int32.TryParse(teamIDString, out int teamID))
                    using (DataContext data = new DataContext())
                    {
                        if (data.Teams.Where(x => x.ID == teamID).Any())
                        {
                            nieuwTeam = data.Teams.Where(x => x.ID == teamID).First();
                            break;
                        }
                        else
                        {
                            Console.Write("Er is geen team gevonden met dit ID, druk op ENTER om verder te gaan...");
                            Console.ReadLine();
                        }
                    }
                else
                {
                    Console.Write("Vul een juist team ID in, druk op ENTER om verder te gaan...");
                    Console.ReadLine();
                }
            }

            while (true)
            {
                Console.WriteLine("----- [MAAK TRANSFER] -----");
                Console.Write("Transfer prijs?: ");
                String prijsString = Console.ReadLine();
                if (Int32.TryParse(prijsString, out prijs))
                {
                    if (prijs > 0)
                    {
                        break;
                    }
                    else
                    {
                        Console.Write("Prijs moet meer dan  zijn dan 0, druk op ENTER om verder te gaan...");
                        Console.ReadLine();
                    }
                }
                else
                {
                    Console.Write("Input moet een juist nummer zijn, druk op ENTER om verder te gaan...");
                    Console.ReadLine();
                }
            }

            using (DataContext data = new DataContext())
            {
                speler.Team = nieuwTeam;
                speler.TeamID = nieuwTeam.ID;
                nieuwTeam.Spelers.Add(speler);
                if (oudeTeam != null)
                {
                    oudeTeam.Spelers.Remove(speler);
                }
                Transfer transfer = new Transfer(0, prijs, speler, oudeTeam, nieuwTeam);
                data.Transfers.Add(transfer);
                data.SaveChanges();
            }

            Console.Write("Nieuwe transfer is toegevoegd, druk op ENTER om verder te gaan...");
            Console.ReadLine();
        }

        private static void PrintTransfers()
        {
            Console.WriteLine("----- [TRANSFER LIJST] -----");
            using (DataContext data = new DataContext())
            {
                foreach (Transfer transfer in data.Transfers)
                    PrintTransfer(transfer);
            }
            Console.WriteLine(" ");
            Console.Write("druk op ENTER om verder te gaan...");
            Console.ReadLine();
        }
        private static void PrintTransfer(Transfer transfer)
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine($"ID: {transfer.ID}, Player:  {transfer.SpelerID}, Old Team:  {transfer.OudeTeamID}, New Team:  {transfer.NieuwTeamID}, Price: {transfer.Prijs}");
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}