﻿using LeagueConsole.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LeagueConsole.Managers
{
    public class TeamManager
    {
        public static void BeheerTeam()
        {
            Boolean afspelen = true;
            while (afspelen)
            {
                Console.WriteLine("----- [TEAM] -----");
                Console.WriteLine("[1] VOEG TEAM TOE");
                Console.WriteLine("[2] UPDATE TEAM");
                Console.WriteLine("[3] VERWIJDER TEAM");
                Console.WriteLine("[4] PRINT TEAMS");
                Console.WriteLine("[5] GA TERUG");
                Console.Write("Selectie?: ");
                String selectie = Console.ReadLine();

                switch (selectie)
                {
                    case "1":
                        VoegTeamToe();
                        break;
                    case "2":
                        UpdateTeam();
                        break;
                    case "3":
                        VerwijderTeam();
                        break;
                    case "4":
                        PrintTeams();
                        break;
                    case "5":
                        afspelen = false;
                        break;
                    default:
                        Console.Write("Verkeerde input ingegeven, druk op ENTER om verder te gaan...");
                        Console.ReadLine();
                        break;
                }
            }
        }

        private static void PrintTeams()
        {
            Console.WriteLine("----- [TEAM LIJST] -----");
            using (DataContext data = new DataContext())
            {
                foreach (Team team in data.Teams)
                    PrintTeam(team);
            }
            Console.WriteLine(" ");
            Console.Write("Druk op ENTER om verder te gaan...");
            Console.ReadLine();
        }

        private static void PrintTeam(Team team)
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine($"ID: {team.ID}, Naam: {team.Naam}, Bijnaam: {team.Bijnaam}, Trainer: {team.Trainer}");
            Console.ForegroundColor = ConsoleColor.White;
        }

        private static void VoegTeamToe()
        {
            String teamNaam;
            String teamBijnaam;
            String teamTrainer;

            while (true)
            {
                Console.WriteLine("----- [VOEG TEAM TOE] -----");
                Console.Write("Team naam?: ");
                teamNaam = Console.ReadLine();
                if (teamNaam != "")
                    break;
                else
                {
                    Console.Write("Vul eerst een teamnaam in, druk op ENTER om verder te gaan...");
                    Console.ReadLine();
                }
            }

            while (true)
            {
                Console.WriteLine("----- [VOEG TEAM TOE] -----");
                Console.Write("Team bijnaam?: ");
                teamBijnaam = Console.ReadLine();
                if (teamBijnaam != "")
                    break;
                else
                {
                    Console.Write("Vul eerst een bijnaam in, druk op ENTER om verder te gaan...");
                    Console.ReadLine();
                }
            }

            while (true)
            {
                Console.WriteLine("----- [VOEG TEAM TOE] -----");
                Console.Write("Team trainer?: ");
                teamTrainer = Console.ReadLine();
                if (teamTrainer != "")
                    break;
                else
                {
                    Console.Write("Vul eerst een trainer toe, druk op ENTER om verder te gaan...");
                    Console.ReadLine();
                }
            }

            using (DataContext data = new DataContext())
            {
                Team t = new Team(0, teamNaam, teamBijnaam, teamTrainer);
                data.Teams.Add(t);
                data.SaveChanges();
            }

            Console.Write("Er is een nieuw team toegevoegd, druk op ENTER om verder te gaan...");
            Console.ReadLine();
        }

        private static void UpdateTeam()
        {
            using (DataContext data = new DataContext())
            {
                while (true)
                {
                    Console.WriteLine("----- [UPDATE TEAM] -----");
                    Console.Write("Team ID?: ");
                    String selectie = Console.ReadLine();
                    if (Int32.TryParse(selectie, out int teamID))
                    {
                        if (data.Teams.Where(x => x.ID == teamID).Any())
                        {
                            UpdateTeam(data.Teams.Where(x => x.ID == teamID).First());
                            data.SaveChanges();
                            break;
                        }
                        else
                        {
                            Console.Write("Er is geen team gevonden met dit ID, druk op ENTER om verder te gaan...");
                            Console.ReadLine();
                            break;
                        }
                    }
                    else
                    {
                        Console.Write("Het gegeven nummer is niet geldig, druk op ENTER om verder te gaan...");
                        Console.ReadLine();
                        break;
                    }
                }
            }
        }

        private static void UpdateTeam(Team team)
        {
            Boolean runMenu = true;
            while (runMenu)
            {
                Console.WriteLine("----- [UPDATE TEAM] -----");
                Console.WriteLine($"Team: {team.ToString()}");
                Console.WriteLine(" ");
                Console.WriteLine("[1] UPDATE NAAM");
                Console.WriteLine("[2] UPDATE BIJNAAM");
                Console.WriteLine("[3] UPDATE TRAINER");
                Console.WriteLine("[4] GA TERUG");
                Console.Write("Selectie: ");
                String selectie = Console.ReadLine();
                switch (selectie)
                {
                    case "1":
                        UpdateTeamNaam(team);
                        break;
                    case "2":
                        UpdateTeamBijnaam(team);
                        break;
                    case "3":
                        UpdateTeamTrainer(team);
                        break;
                    case "4":
                        runMenu = false;
                        break;
                    default:
                        Console.Write("Het gegeven nummer is niet geldig, druk op ENTER om verder te gaan...");
                        Console.ReadLine();
                        break;
                }
            }
        }


        private static void UpdateTeamNaam(Team team)
        {
            while (true)
            {
                Console.WriteLine("----- [UPDATE TEAM NAAM] -----");
                Console.WriteLine("");
                Console.WriteLine($"Team: {team.ToString()}");
                Console.Write("Nieuwe team naam?: ");
                String nieuweTeamNaam = Console.ReadLine();
                if (nieuweTeamNaam != "")
                {
                    team.Naam = nieuweTeamNaam;
                    break;
                }
                else
                {
                    Console.Write("Je moet een teamnaam ingeven, druk op ENTER om verder te gaan...");
                    Console.ReadLine();
                }
            }
        }


        private static void UpdateTeamBijnaam(Team team)
        {
            while (true)
            {
                Console.WriteLine("----- [UPDATE TEAM BIJNAAM] -----");
                Console.WriteLine("");
                Console.WriteLine($"Team: {team.ToString()}");
                Console.Write("Nieuwe team bijnaam?: ");
                String nieuweBijnaam = Console.ReadLine();
                if (nieuweBijnaam != "")
                {
                    team.Bijnaam = nieuweBijnaam;
                    break;
                }
                else
                {
                    Console.Write("Je moet een bijnaam ingeven, druk op ENTER om verder te gaane...");
                    Console.ReadLine();
                }
            }
        }


        private static void UpdateTeamTrainer(Team team)
        {
            while (true)
            {
                Console.WriteLine("----- [UPDATE TEAM BIJNAAM] -----");
                Console.WriteLine("");
                Console.WriteLine($"Team: {team.ToString()}");
                Console.Write("Nieuwe team bijnaam?: ");
                String nieuweNaam = Console.ReadLine();
                if (nieuweNaam != "")
                {
                    team.Trainer = nieuweNaam;
                    break;
                }
                else
                {
                    Console.Write("Je moet een bijnaam ingeven, druk op ENTER om verder te gaane...");
                    Console.ReadLine();
                }
            }
        }

        private static void VerwijderTeam()
        {
            using (DataContext data = new DataContext())
            {
                while (true)
                {
                    Console.WriteLine("----- [VERWIJDER TEAM] -----");
                    Console.Write("Team ID?: ");
                    String selectie = Console.ReadLine();
                    if (Int32.TryParse(selectie, out int teamID))
                    {
                        if (data.Teams.Where(x => x.ID == teamID).Any())
                        {
                            data.Teams.Remove(data.Teams.Where(x => x.ID == teamID).First());
                            data.SaveChanges();

                            Console.Write("Team is verwijderd, druk op ENTER om verder te gaan...");
                            Console.ReadLine();
                            break;
                        }
                        else
                        {
                            Console.Write("Geen team is gevonden met dit ID, druk op ENTER om verder te gaan...");
                            Console.ReadLine();
                            break;
                        }
                    }
                    else
                    {
                        Console.Write("Het gegeven nummer is niet geldig, druk op ENTER om verder te gaan...");
                        Console.ReadLine();
                        break;
                    }
                }
            }
        }
    }
}