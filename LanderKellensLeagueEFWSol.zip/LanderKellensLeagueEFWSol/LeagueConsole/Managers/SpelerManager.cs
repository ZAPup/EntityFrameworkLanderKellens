﻿using LeagueConsole.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LeagueConsole.Managers
{
    public class SpelerManager
    {
        public static void BeheerSpeler()
        {
            Boolean afspelen = true;
            while (afspelen)
            {
                Console.WriteLine("----- [SPELER] -----");
                Console.WriteLine("[1] VOEG SPELER TOE");
                Console.WriteLine("[2] PAS SPELER AAN");
                Console.WriteLine("[3] VERWIJDER SPELER");
                Console.WriteLine("[4] PRINT SPELER");
                Console.WriteLine("[5] GA TERUS");
                Console.Write("Selectie?: ");
                String selectie = Console.ReadLine();

                switch (selectie)
                {
                    case "1":
                        VoegSpelerToe();
                        break;
                    case "2":
                        PasSpelerAan();
                        break;
                    case "3":
                        VerwijderSpeler();
                        break;
                    case "4":
                        PrintSpeler();
                        break;
                    case "5":
                        afspelen = false;
                        break;
                    default:
                        Console.Write("Verkeerde input van de gebruiker, Druk op ENTER om verder te gaan...");
                        Console.ReadLine();
                        break;
                }
            }
        }
        private static void PrintSpeler()
        {
            Console.WriteLine("----- [SPELERS LIJST] -----");
            using (DataContext Data = new DataContext())
            {
                foreach (Speler speler in Data.Spelers)
                    PrintSpeler(speler);
            }
            Console.WriteLine(" ");
            Console.Write("Druk op ENTER om verder te gaan...");
            Console.ReadLine();
        }

        private static void PrintSpeler(Speler speler)
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            Console.WriteLine($"ID: {speler.ID}, Naam: {speler.Naam}, Nummer: {speler.Nummer}, Score: {speler.TotaleScore}, Team: {speler.TeamID}, Waarde: {speler.Waarde}");
            Console.ForegroundColor = ConsoleColor.White;
        }

        private static void VoegSpelerToe()
        {
            string spelerNaam;
            int spelerNummer;
            double spelerScore;
            Team spelerTeam;
            int spelerWaarde;

            while (true)
            {
                Console.WriteLine("----- [VOEG SPELER TOE] -----");
                Console.Write("Speler naam?: ");
                spelerNaam = Console.ReadLine();
                if (spelerNaam != null)
                    break;
                else
                {
                    Console.Write("Je moet een naam geven aan de speler, druk op ENTER om verder te gaan...");
                    Console.ReadLine();
                }
            }

            while (true)
            {
                Console.WriteLine("----- [VOEG SPELER TOE] -----");
                Console.Write("Speler nummer?: ");
                String spelerNummerString = Console.ReadLine();
                if (Int32.TryParse(spelerNummerString, out spelerNummer))
                    break;
                else
                {
                    Console.Write("Je moet een nummer geven aan je speler, druk op ENTER om verder te gaan...");
                    Console.ReadLine();
                }
            }

            while (true)
            {
                Console.WriteLine("----- [VOEG SPELER TOE] -----");
                Console.Write("Speler Score?: ");
                String spelerScoreString = Console.ReadLine();
                if (Double.TryParse(spelerScoreString, out spelerScore))
                    break;
                else
                {
                    Console.Write("Je moet een score geven aan je speler, druk op ENTER om verder te gaan...");
                    Console.ReadLine();
                }
            }

            while (true)
            {
                Console.WriteLine("----- [VOEG SPELER TOE] -----");
                Console.Write("Speler team?: ");
                String teamIDString = Console.ReadLine();
                if (Int32.TryParse(teamIDString, out int teamID))
                    using (DataContext data = new DataContext())
                    {
                        if (data.Teams.Where(x => x.ID == teamID).Any())
                        {
                            spelerTeam = data.Teams.Where(x => x.ID == teamID).First();
                            break;
                        }
                        else
                        {
                            Console.Write("Geen team gevonden met dat ID, druk op ENTER om verder te gaan...");
                            Console.ReadLine();
                        }
                    }
                else
                {
                    Console.Write("Je moet een juist team ID ingeven, druk op ENTER om verder te gaan...");
                    Console.ReadLine();
                }
            }

            while (true)
            {
                Console.WriteLine("----- [VOEG SPELER TOE] -----");
                Console.Write("Speler waarde?: ");
                String spelerWaardeID = Console.ReadLine();
                if (Int32.TryParse(spelerWaardeID, out spelerWaarde))
                    break;
                else
                {
                    Console.Write("Je moet een juiste waarde ingeven voor je speler, druk op ENTER om verder te gaan...");
                    Console.ReadLine();
                }
            }

            using (DataContext data = new DataContext())
            {
                Speler speler = new Speler(0, spelerNummer, spelerNaam, spelerScore, spelerTeam, spelerWaarde);
                data.Spelers.Add(speler);
                data.SaveChanges();
            }

            Console.Write("Nieuwe speler is toegevoegd, druk op ENTER om verder te gaan...");
            Console.ReadLine();
        }

        private static void PasSpelerAan()
        {
            using (DataContext data = new DataContext())
            {
                while (true)
                {
                    Console.WriteLine("----- [UPDATE SPELER] -----");
                    Console.Write("Speler ID?: ");
                    String selectie = Console.ReadLine();
                    if (Int32.TryParse(selectie, out int spelerID))
                    {
                        if (data.Spelers.Where(x => x.ID == spelerID).Any())
                        {
                            UpdateSpeler(data.Spelers.Where(x => x.ID == spelerID).First());
                            data.SaveChanges();
                            break;
                        }
                        else
                        {
                            Console.Write("Er is geen speler gevonden met dat ID, druk op ENTER om verder te gaan...");
                            Console.ReadLine();
                            break;
                        }
                    }
                    else
                    {
                        Console.Write("De gegeven nummer is een onjuist nummer, druk op ENTER om verder te gaan...");
                        Console.ReadLine();
                        break;
                    }
                }
            }
        }

        private static void UpdateSpeler(Speler speler)
        {
            Boolean afspelen = true;
            while (afspelen)
            {
                Console.WriteLine("----- [UPDATE TEAM] -----");
                Console.WriteLine($"Speler: [ID: {speler.ID}] {speler.Naam}");
                Console.WriteLine(" ");
                Console.WriteLine("[1] UPDATE NAAM");
                Console.WriteLine("[2] UPDATE NUMMER");
                Console.WriteLine("[3] UPDATE SCORE");
                Console.WriteLine("[4] GA TERUG");
                Console.Write("Selectie: ");
                String selectie = Console.ReadLine();
                switch (selectie)
                {
                    case "1":
                        UpdateSpelersNaam(speler);
                        break;
                    case "2":
                        UpdateSpelerNummer(speler);
                        break;
                    case "3":
                        UpdateSpelerScore(speler);
                        break;
                    case "4":
                        afspelen = false;
                        break;
                    default:
                        Console.Write("Verkeerde input van de gebruiker, Druk op ENTER om verder te gaan...");
                        Console.ReadLine();
                        break;
                }
            }
        }

        private static void UpdateSpelersNaam(Speler speler)
        {
            while (true)
            {
                Console.WriteLine("----- [UPDATE SPELER NAAM] -----");
                Console.WriteLine($"Speler: [ID: {speler.ID}] {speler.Naam}");
                Console.WriteLine("");
                Console.Write("Nieuwe spelers naam?: ");
                String nieuweNaam = Console.ReadLine();
                if (nieuweNaam != "")
                {
                    speler.Naam = nieuweNaam;
                    break;
                }
                else
                {
                    Console.Write("Je moet een naam geven aan je speler, Druk op ENTER om verder te gaan...");
                    Console.ReadLine();
                }
            }
        }

        private static void UpdateSpelerNummer(Speler player)
        {
            while (true)
            {
                Console.WriteLine("----- [UPDATE SPELER NUMMER] -----");
                Console.WriteLine($"Speler: [ID: {player.ID}] {player.Naam}");
                Console.WriteLine("");
                Console.Write("Nieuwe speler nummer?: ");
                String nieuwSpelerNummerString = Console.ReadLine();
                if (Int32.TryParse(nieuwSpelerNummerString, out int nummer))
                {
                    player.Nummer = nummer;
                    break;
                }
                else
                {
                    Console.Write("De gegeven nummer was incorrect, Druk op ENTER om verder te gaan...");
                    Console.ReadLine();
                }
            }
        }

        private static void UpdateSpelerScore(Speler speler)
        {
            while (true)
            {
                Console.WriteLine("----- [UPDATE SPELER SCORE] -----");
                Console.WriteLine($"Speler: [ID: {speler.ID}] {speler.Naam}");
                Console.WriteLine("");
                Console.Write("Nieuwe speler score?: ");
                String nieuweSpelerScoreString = Console.ReadLine();
                if (Double.TryParse(nieuweSpelerScoreString, out double score))
                {
                    speler.TotaleScore = score;
                    break;
                }
                else
                {
                    Console.Write("De gegeven score was incorrect, Druk op ENTER om verder te gaan...");
                    Console.ReadLine();
                }
            }
        }


        private static void VerwijderSpeler()
        {
            using (DataContext data = new DataContext())
            {
                while (true)
                {
                    Console.WriteLine("----- [VERWIJDER SPELER] -----");
                    Console.Write("Speler ID?: ");
                    String selectie = Console.ReadLine();
                    if (Int32.TryParse(selectie, out int spelerID))
                    {
                        if (data.Spelers.Where(x => x.ID == spelerID).Any())
                        {
                            data.Spelers.Remove(data.Spelers.Where(x => x.ID == spelerID).First());
                            data.SaveChanges();

                            Console.Write("Speler is verwijderd, Druk op ENTER om verder te gaan...");
                            Console.ReadLine();
                            break;
                        }
                        else
                        {
                            Console.Write("Geen speler gevonden met dat ID, Druk op ENTER om verder te gaan...");
                            Console.ReadLine();
                            break;
                        }
                    }
                    else
                    {
                        Console.Write("Input was niet correct, Druk op ENTER om verder te gaan...");
                        Console.ReadLine();
                        break;
                    }
                }
            }
        }

    }
}