﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LeagueConsole.Managers
{
    public class EditManager
    {
        public static void AanpasMenu()
        {
            Boolean afspelen = true;
            while (afspelen)
            {
                Console.WriteLine("----- [AANPAS MENU] -----");
                Console.WriteLine("[1] PAS TEAMS AAN");
                Console.WriteLine("[2] PAS SPELERS AAN");
                Console.WriteLine("[3] MAAK EEN TRANSFER");
                Console.WriteLine("[4] GA TERUG");
                Console.Write("Selectie?: ");
                String selectie = Console.ReadLine();

                switch (selectie)
                {
                    case "1":
                        TeamManager.BeheerTeam();
                        break;
                    case "2":
                        SpelerManager.BeheerSpeler();
                        break;
                    case "3":
                        TransferManager.BeheerTransfer();
                        break;
                    case "4":
                        afspelen = false;
                        break;
                    default:
                        Console.Write("Verkeerde input van de gebruiker, Druk op ENTER om verder te gaan...");
                        Console.ReadLine();
                        break;
                }
            }
        }
    }
}