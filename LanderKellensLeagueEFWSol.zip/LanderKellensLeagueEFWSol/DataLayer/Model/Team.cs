﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace LeagueConsole.Model
{
    public class Team
    {
        public Team(int ID, String Naam, string Bijnaam, string Trainer)
        {
            this.ID = ID;
            this.Naam = Naam;
            this.Bijnaam = Bijnaam;
            this.Trainer = Trainer;
            this.Spelers = new List<Speler>();
        }

        [Key]
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int ID { get; set; }
        public String Naam { get; set; }
        public String Bijnaam { get; set; }
        public String Trainer { get; set; }
        public ICollection<Speler> Spelers { get; set; }

        public override string ToString()
        {
            return $"[ID {this.ID}] {this.Naam}";
        }

    }
}
