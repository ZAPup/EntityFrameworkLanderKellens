﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace LeagueConsole.Model
{
    public class Speler
    {
        public Speler(int ID, int Nummer, String Naam, double TotaleScore, int TeamID, int Waarde)
        {
            this.ID = ID;
            this.Nummer = Nummer;
            this.Naam = Naam;
            this.TotaleScore = TotaleScore;
            this.Team = null;
            this.TeamID = TeamID;
            this.Waarde = Waarde;
        }

        public Speler(int ID, int Number, String Name, double TotalScore, Team team, int value)
        {
            this.ID = ID;
            this.Nummer = Number;
            this.Naam = Name;
            this.TotaleScore = TotalScore;
            this.Team = team;
            this.TeamID = team.ID;
            this.Waarde = value;
        }

        [Key]
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int ID { get; set; }
        public int Nummer { get; set; }
        public String Naam { get; set; }
        public Double TotaleScore { get; set; }
        public int TeamID { get; set; }
        public int Waarde { get; set; }

        [NotMapped]
        public Team Team { get; set; }
    }
}
