﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace LeagueConsole.Model
{
    public class Transfer
    {
        public Transfer(int ID, Double prijs, int spelerID, int oudeTeamID, int nieuwTeamID)
        {
            this.ID = ID;
            this.Prijs = prijs;
            this.SpelerID = spelerID;
            this.OudeTeamID = oudeTeamID;
            this.NieuwTeamID = nieuwTeamID;
        }

        public Transfer(int ID, double prijs, Speler speler, Team oudeTeam, Team nieuweTeam)
        {
            this.ID = ID;
            this.Prijs = prijs;
            this.Speler = speler;
            this.SpelerID = speler.ID;
            this.OudeTeam = oudeTeam;
            this.OudeTeamID = oudeTeam.ID;
            this.NieuwTeam = nieuweTeam;
            this.NieuwTeamID = nieuweTeam.ID;
        }

        [Key]
        [DatabaseGeneratedAttribute(DatabaseGeneratedOption.Identity)]
        public int ID { get; set; }
        public Double Prijs { get; set; }
        public int OudeTeamID { get; set; }
        public int NieuwTeamID { get; set; }
        public int SpelerID { get; set; }

        [NotMapped]
        public Speler Speler { get; set; }
        [NotMapped]
        public Team OudeTeam { get; set; }
        [NotMapped]
        public Team NieuwTeam { get; set; }
    }
}
