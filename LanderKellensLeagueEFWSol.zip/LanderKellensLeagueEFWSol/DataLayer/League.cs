﻿using LeagueConsole.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataLayer
{
    public class League
    {
        private List<Speler> Spelers = new List<Speler>();
        private List<Team> Teams = new List<Team>();
        private List<Transfer> Transfers = new List<Transfer>();

        public League()
        {

        }

        public void VoegSpelerToe(Speler speler)
        {
            Spelers.Add(speler);
        }

        public void VoegTeamToe(Team team)
        {
            Teams.Add(team);
        }

        public void VoegTransferToe(Transfer transfer)
        {
            Transfers.Add(transfer);
        }

        public Speler KrijgSpeler(int ID)
        {
            return Spelers.First(x => x.ID.Equals(ID));
        }

        public Team KrijgTeam(int ID)
        {
            return Teams.First(x => x.ID.Equals(ID));
        }

        public Transfer KrijgTransfer(int ID)
        {
            return Transfers.First(x => x.ID.Equals(ID));
        }

        public List<Speler> KrijgAlleSpelers()
        {
            return Spelers;
        }

        public List<Team> KrijgTeams()
        {
            return Teams;
        }

        public List<Transfer> KrijgAlleTransfers()
        {
            return Transfers;
        }

        public void UpdateSpeler(Speler speler)
        {
            int positie = Spelers.FindIndex(x => x.ID.Equals(speler.ID));
            Spelers[positie] = speler;
        }

        public void UpdateTeam(Team team)
        {
            int positie = Teams.FindIndex(x => x.ID.Equals(team.ID));
            Teams[positie] = team;
        }
    }
}
